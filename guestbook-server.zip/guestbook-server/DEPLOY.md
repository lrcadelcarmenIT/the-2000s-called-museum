# Shared guestbook — free deploy on Render

This tiny backend lets every visitor to the museum see everyone else's
guestbook entries. It has no dependencies and stores entries in a local
`entries.json` file.

## Deploy (free)

1. Create a free account at https://render.com and open the dashboard.
2. Click **New + → Web Service**.
3. Connect your GitHub account and pick the repository that contains this
   folder (`guestbook-server/`).
4. In the service settings:
   - **Root Directory:** `guestbook-server`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - Leave the plan on **Free**.
5. Click **Create Web Service**. Render will give you a URL like
   `https://two-thousands-called-guestbook.onrender.com`.

## Connect the museum page

1. Open `index.html` (the museum page) and find near the top of the script:
   ```js
   const GUESTBOOK_API_URL='';
   ```
2. Paste your Render URL between the quotes:
   ```js
   const GUESTBOOK_API_URL='https://two-thousands-called-guestbook.onrender.com';
   ```
3. Re-push `index.html` to GitHub. The guestbook will show a green
   "● Live · shared with all visitors" badge, and new entries appear for
   everyone.

If the backend is ever unreachable, the page automatically falls back to
the old behavior (entries stored in the visitor's own browser) and shows a
note saying so — the guestbook never breaks.

## Test locally first (optional)

```bash
cd guestbook-server
npm start
# then in another terminal:
curl http://localhost:3000/health
curl -X POST http://localhost:3000/api/entries \
  -H 'Content-Type: application/json' \
  -d '{"who":"Test","where":"Manila","msg":"Kumusta!"}'
curl http://localhost:3000/api/entries
```

## Free-tier caveat

On Render's free plan the filesystem is ephemeral: `entries.json` can be
wiped when the service restarts or redeploys. For a class demo that is
fine — entries simply start fresh. If you ever need entries to survive
restarts, attach a Render persistent disk or switch to a tiny database.
